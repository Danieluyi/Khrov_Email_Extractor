# Khrov_Email_Extractor
Offline Email Extractor Application For PC

<!-- DISCLAIMER
By downloading/running this free software, you consent to be fully responsible for your actions. I shall not be held liable for any damages or legal matters that may arise upon yur use of this program. -->

This is the first draft of my mini email extractor app written from scratch (besides the use of write() function). Update for both aesthetics and improved cases will be coming soon.

It uses a limited algorithm at the moment, more edge cases and email cloaks will be covered in my next updates.

Covered in the current update are the following email cyphers:
lorem [AT] ipsum [DOT] com
lorem (AT) ipsum [DOT] com
lorem *AT* ipsum *DOT* com
For the .com, .net and .org domain extensions.


HOW TO USE:

#1 Download the file named KHROV_Email_extractor.tar

#2 Extract and you will find 4 files within (KHROV_Email_extractor.exe, input.txt, output.txt, ReadMe.txt) 

#3 Open the text document named "input.txt" and paste the raw inputs into it

#4 Save the "input.txt" and close.

#5 Now open the the KHROV_Email_extractor.exe file. If you followed step #3 and #4 above, the app window should now ask for your confirmation before it runs. Type Y and press the Enter key.

#6 When you see a success message, open the "output.txt" text document to view all extracted emails.
